http://www.sigen.gov.ar/resoluciones.asp 190.210.150.234 20120205011945 text/html 23046
HTTP/1.1 200 OK
Connection:close
Date:Sun, 05 Feb 2012 01:21:11 GMT
Server:Microsoft-IIS/6.0
X-Powered-By:ASP.NET
Content-Length:22813
Content-Type:text/html
Cache-control:private
x-commoncrawl-DetectedCharset:ISO-8859-1



<html>
<head>
<title>Sindicatura General De La Naci�n</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="Css/Estilos.css" rel="stylesheet" type="text/css">


<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo25 {color: #0099FF}
.Estilo26 {color: #CCCCCC}
-->
</style>
<script>
		function AddOrganismo()				{
				
				if (document.all.cboOrganismoSel.value==0)	//Valida que se haya seleccionado un item para agregar.
					{
						window.alert('Debe seleccionar un organismo para agregarlo a la lista.');
					}
				else
					{
						var i;	//Para el bucle.
						var lId=document.all.cboOrganismoSel.value;
						var sEnte=document.all.ED_cboOrganismoSel.value; //y la Descripci�n.
						for (i=0;i<document.all.cboOrganismo.length;i++)
							{
								if (lId==document.all.cboOrganismo.options[i].value)	
									{
										window.alert('El organismo seleccionado ya se encuentra en la lista.');
										return false;
									}
							}
						var anOption=document.createElement("OPTION");	//Crea un objeto OPTION,
						document.all.cboOrganismo.options.add(anOption);	//y lo agrega a la lista.
						anOption.innerText=sEnte;	//Asigna las propiedades.
						anOption.value=lId;
						document.all.cboOrganismoSel.value = '';
						document.all.ED_cboOrganismoSel.value = '';
					}
			}
	
	function popEntes(id)
		{
			var desc = document.getElementById("ED_"+id).value;
			newWindow = window.open("BuscarEnte.asp?control="+id+"&E=" + desc ,"Entes","left=100,top=100,width=680,height=380,scrollbars=yes,status=yes");
		}

	function DoFechas(){
			var combo = frmQuery.cboAnio.options[frmQuery.cboAnio.selectedIndex];
			//var combo = frmQuery.cboAnio.selectedIndex.value;
			//alert (combo.value);
			if (combo.value == ''){
				frmQuery.calDesde.value = '01/01/2012';
				frmQuery.calHasta.value = '31/12/2012';
				}
				else
				{
				frmQuery.calDesde.value = '01/01/'+ combo.value;
				frmQuery.calHasta.value = '31/12/'+ combo.value;
				}

		}

</script>
</head>

<body>
<table width="955" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 <!--DWLayoutTable-->
	<tr>
		<td height="100" colspan=3 valign="top" bgcolor="#FFFFFF">
			<link href="css/estilos.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo20 {
	color: #000066;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: bold;
}
#Layer1 {
	position:absolute;
	left:582px;
	top:57px;
	width:274px;
	height:33px;
	z-index:1;
}
-->
</style>
<table width="955" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
	<!--DWLayoutTable-->
	<tr>
		<td height="100" colspan="4" valign="top"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="955" height="100" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="header_sigen03.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" /><embed src="header_sigen03.swf" quality="high" bgcolor="#ffffff" width="955" height="100" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />

</object>
		</td>
  </tr>
	
	
	
	
	<tr>
	 <td width="14" height="18" valign="top" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
 <td width="136" valign="middle" bgcolor="#FFFFFF" class="Estilo20"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;S I G E N</td>
  <td width="598" align="center" valign="top" bgcolor="#FFFFFF" class="font5"><a href="institucional.asp" class="font5">Institucional</a> &nbsp; &nbsp;&nbsp;- &nbsp;&nbsp;&nbsp;<a href="informes.asp" class="font5">Informes</a>&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp; <a href="normativa.asp" class="font5">Normativa</a>&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp; <a href="plananual2011.asp" class="font5">Plan Anual </a>&nbsp; &nbsp;<a href="resoluciones.asp" class="font5"></a>- &nbsp;&nbsp;&nbsp;<a href="resoluciones.asp" class="font5">Resoluciones</a>&nbsp;&nbsp;&nbsp;&nbsp;</td>
  <td width="207" valign="top" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
	</tr>
</table>


</td>
 </tr>
	<tr>
	  <td width="160" rowspan="3"  valign="top" bgcolor="#FFFFFF">
   <link href="Includes/css/estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo21 {
	color: #0099FF;
	font-size: 10px;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style><body onLoad="MM_preloadImages('images/menu_redfederal_ovr.jpg','images/menu_mercosur_ovr.jpg','Iimages/menu_multiarte_ovr.jpg','images/menu_gobierno_ovr.jpg','images/menu_enlaces_ovr.jpg')">
<table width="160" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">


		<tr align="center" valign="middle">
		 <td height="345" valign="top">
		 <br />
			 <table cellpadding="0px" cellspacing="0px" height="150px">
			 <!--DWLayoutTable-->
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="red.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/menu_redfederal_ovr.jpg',1)"><img src="images/menu_redfederal.jpg" alt="red federal de control p&uacute;blico" name="Image1" width="144" height="65" border="0"></a></div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="mercosur.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/menu_mercosur_ovr.jpg',1)"><img src="images/menu_mercosur.jpg" alt="temas de control mercosur" name="Image2" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="multiarte.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/menu_multiarte_ovr_2012.jpg',1)"><img src="images/menu_multiarte_2012.jpg" alt="espacio multiarte" name="Image3" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="gobierno.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','images/menu_gobierno_ovr.jpg',1)"><img src="images/menu_gobierno.jpg" alt="enlaces gobierno de la republica argentina" name="Image4" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				
			   <tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="contrataciones.asp" target="_self" onMouseOver="MM_swapImage('Image6','','images/menu_contrataciones_ovr.jpg',1)" onMouseOut="MM_swapImgRestore()"><img src="images/menu_contrataciones.jpg" alt="compras y contrataciones" name="Image6" width="144" height="65" border="0"></a></div></td>
			   </tr>
			   <tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="enlaces.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image5','','images/menu_enlaces_ovr.jpg',1)"><img src="images/menu_enlaces.jpg" alt="enlaces organizaciones de control en el mundo" name="Image5" width="144" height="65" border="0"></a></div></td>
			   </tr>
				<tr>
				 <td width="4" height="13" ></td>
				 <td width="137" valign="top" class="fuentepequena" ><a href="terminosycondiciones.asp" class="small Estilo13">T&eacute;rminos y Condiciones </a></td>
				 <td width="4" ></td>
			   </tr>
				<tr>
				 <td height="5" ></td>
				 <td ></td>
				 <td ></td>
			   </tr>
           </table></td>
   <td>&nbsp;</td>
	</tr>
		<tr align="center" valign="middle">
		 <td height="31">&nbsp;</td>
		 <td>&nbsp;</td>
 </tr>
</table>
</td>
	
		<td width="620" height="702" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
		  <!--DWLayoutTable-->
		  <tr>
		   <td width="20" height="2"></td>
		   <td width="570" valign="top" bgcolor="#CCCCCC"><img src="decoratives/line_resoluciones.gif" width="570" height="2"></td>
		  <td width="30"></td>
		  </tr>
		  <tr>
		   <td height="20"></td>
		   <td valign="top" class="small"><div align="right" class="Estilo25">&nbsp; <img src="decoratives/triangulito_resoluciones.gif" width="5" height="9" align="absmiddle"> <span class="small_resoluciones">Resoluciones Sigen </span></div></td>
	    <td></td>
		  </tr>
		  
		  <tr>
		   <td height="60"></td>
		   <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="decoratives/head_resoluciones.gif">
		    <!--DWLayoutTable-->
		    <tr>
		     <td width="290" height="37">&nbsp;</td>
		     <td width="280" valign="bottom"><div align="right"><span class="boldear Estilo26"><br>
		        <span class="Estilo13">Resoluciones </span></span></div></td>
		     </tr>
		    <tr>
		     <td height="23">&nbsp;</td>
		     <td>&nbsp;</td>
		     </tr>
	    </table></td>
		   <td></td>
	   </tr>
		  <tr>
		   <td height="14"></td>
		   <td></td>
		   <td></td>
	   </tr>
		  <tr>
		    <td height="487"></td>
		    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
		      <!--DWLayoutTable-->
		      <tr>
		        <td width="50" height="69" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
          <td width="520" rowspan="8" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
            <!--DWLayoutTable-->
            <tr>
              
              
              <form name="frmQuery" method="post" action="Result_resoluciones.asp" AUTOCOMPLETE="OFF">
                
                
                
                
                
                <td width="417" height="83" valign="top" class="tit_02_informes">
                  <p>&nbsp;</p>
									     <p>N&uacute;mero:<br>
									       <input name="txtNumero" type="text" class="DatoInpF" style="width:120px">									 
									       &nbsp;<br>
									       <br>
								         </p>										 </td>
            <td width="103">&nbsp;</td>
           
									
									  <tr>
									    <td height="49" valign="top" class="tit_02_informes"><p>A&ntilde;o:<br>
									      <select name="cboAnio" class="DatoInpF" style="width:90px">
									        <Option value="-1">Todos</Option>
									        <Option value='2012' selected>2012</Option>
<Option value='2011'>2011</Option>
<Option value='2010'>2010</Option>
<Option value='2009'>2009</Option>
<Option value='2008'>2008</Option>
<Option value='2007'>2007</Option>
<Option value='2006'>2006</Option>
<Option value='2005'>2005</Option>
<Option value='2004'>2004</Option>
<Option value='2003'>2003</Option>
<Option value='2002'>2002</Option>
<Option value='2001'>2001</Option>
<Option value='2000'>2000</Option>
<Option value='1999'>1999</Option>
<Option value='1998'>1998</Option>
<Option value='1997'>1997</Option>
<Option value='1996'>1996</Option>
<Option value='1995'>1995</Option>
<Option value='1994'>1994</Option>
<Option value='1993'>1993</Option>
	
								          </select>
									      &nbsp;<br>
									      <br>
									      </p></td>
            <td>&nbsp;</td>
           </tr>
									    <!--tr>
									 <td height="65" valign="top" class="tit_02_informes">
            <p>Rango de Fechas:<br>
										   Desde:&nbsp;&nbsp;										   <input name="calDesde" class="DatoInpF" value="01/01/2012" size="11" onfocus="this.blur()">
								<a href="javascript:void(0)" onclick="if(self.gfPop)gfPop.fStartPop(document.frmQuery.calDesde,document.frmQuery.calHasta);return false;">
									<img name="popcal" align="absmiddle" src="datecal/calbtn.gif" width="34" height="22" border="0" alt>
								</a>
								<img src="datecal/delete.gif" style="cursor:hand;" onclick="calDesde.value='';" WIDTH="15" HEIGHT="16"> &nbsp;&nbsp;&nbsp;&nbsp;Hasta:&nbsp;&nbsp;
								<input name="calHasta" class="DatoInpF" value="31/12/2012" size="11" onfocus="this.blur()">
								<a href="javascript:void(0)" onclick="if(self.gfPop)gfPop.fEndPop(document.frmQuery.calDesde,document.frmQuery.calHasta);return false;">
									<img name="popcal" align="absmiddle" src="datecal/calbtn.gif" width="34" height="22" border="0" alt>
								</a>
								<img src="datecal/delete.gif" style="cursor:hand;" onclick="calHasta.value='';" WIDTH="15" HEIGHT="16">
&nbsp;<br>
                                                                                                                                                                            </p></td>
          <td>&nbsp;</td>
									 </tr-->
									    <tr>
									      <td height="66" valign="top" class="tit_02_informes"><p>Palabras clave:<br>
									        <input name="txtKeywords" type="text" class="DatoInpF" style="width:378px">									 
									        &nbsp;<br>
									        <br>
									        </p></td>
            <td>&nbsp;</td>
									   </tr>
									      <tr>
									        <td height="42" valign="top">
									          <p>
									            <input type="image" src="Images/btnBuscar.gif" value="Buscar" name="btnSubmit" WIDTH="80" HEIGHT="16">
									            &nbsp;&nbsp;&nbsp;
									            <img src="Images/btnLimpiar.gif" onClick="frmQuery.reset();" style="cursor:hand;" WIDTH="80" HEIGHT="16">
									            <input type="Hidden" value="Filtrar" name="hdnAccion">
  &nbsp;</p>
								            <p>&nbsp;</p>
								            <p>&nbsp;</p></td>
            <td>&nbsp;</td>
									   </tr>
			          </form>
            </table></td>
	          </tr>
		      <tr>
		        <td height="190"></td>
	          </tr>
		      <tr>
		        <td height="203"></td>
	          </tr>
		     
		     
		   
		  
		      
		      
            </table></td>
		   <td></td>
	      </tr>
		  <tr>
		    <td height="104"></td>
		    <td valign="top"><p>&nbsp;</p>
		      <p>&nbsp;</p>
		      <p>&nbsp;</p>
		      <p>&nbsp;</p>
		      <p>&nbsp;</p>
		      <p><img src="decoratives/line_resoluciones.gif"  width="570" height="5"><br>
                <br>
		          <span class="Texto2"><strong>SINDICATURA GENERAL DE LA NACION</strong><br>
	              Av. Corrientes 389<br>
	              C1043AAD / Ciudad Aut&oacute;noma de Buenos Aires<br>
	              Capital Federal / Rep&uacute;blica Argentina<br>
	              Tel.: (54+11) 4312 8111/18<br>
            Fax: (54+11) 4317 2828</span></p></td>
		   <td></td>
	      </tr>
		  <tr>
		    <td height="15"></td>
		    <td></td>
		    <td></td>
	      </tr>
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
        </table></td>
		<td width="175" rowspan="4" valign="top">
			<!--INCLUDE DE LA AGENDA-->
			<link href="css/estilos.css" rel="stylesheet" type="text/css">
<table width="148px" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
	<tr>
<td width="152" height="476" valign="top"><p>		<img src="main_principal/redes_sociales_iconos.jpg" alt="LINKEDIN / FACEBOOK" width="148" height="150" border="0" usemap="#Map" /><br />
    <!--p style="text-align:center;">Subscribirse:<br />
    		<a href="atom.asp" target="_blank"><img src="images/atom-icon.gif" alt="Subscripci�n a las novedades Sigen fuente Atom" width="50" height="14" border="0" /></a>&nbsp;
    		<a href="rss.asp" target="_blank"><img src="images/rss-icon.gif" alt="Subscripci�n a las novedades Sigen fuente RSS 2.0" width="50" height="14" border="0" /></a>
	  </p-->
	  
      <br />
      <a href="http://www.jornadasptnsigen.gov.ar" target="_blank"><img src="images/logo_abogacia_estatal.jpg" alt="primeras jornadas internacionales - la abogacia estatal y el control gubernamental" width="148" height="105" border="0" /></a><br />
      <br />
		<a href="http://www.iscgp.gov.ar" target="_blank">
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="60" title="Instituto Superior de Control de la Gesti&oacute;n P&uacute;blica">
          <param name="movie" value="main_principal/ISCGP_FLASH.swf" />
          <param name="quality" value="high" />
          <embed src="main_principal/ISCGP_FLASH.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="60" ></embed>
        </object>
		</a><br />
				<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="100" title="contacto con el ciudadano">
					<param name="movie" value="main_principal/flash/ciudadanos2.swf"/>
					<param name="quality" value="high" />
					<embed src="main_principal/flash/ciudadanos2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="100"></embed>
				</object>
			
			  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="100" title="envio de curriculum">
                <param name="movie" value="main_principal/flash/curriculum2.swf" />
                <param name="quality" value="high" />
                <embed src="main_principal/flash/curriculum2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="100"></embed>
              </object>
			  <a href="https://www.argentinacompra.gov.ar" target="_blank"><img src="images/logo_compra_argentina.jpg" alt="argentina compra" width="148" height="53" border="0" />		</a><br />
			  <br />
      <a href="http://www.bicentenario.argentina.ar/" target="_blank"><img src="main_principal/banner_bicentenario.jpg" alt="agenda del bicentenario" width="148" height="73" border="0" /><br />
			    <br />
      </a>
				<a href="http://www.marcaargentina.gov.ar/" target="_blank"><img src="images/logo_marca_argentina.jpg" alt="argentina tiene marca" width="148" height="55" border="0" /></a><br />
				<br />
				<a href="http://www.mejordemocracia.gov.ar/" target="_blank"><img src="images/logo_mejordemocracia.jpg" alt="mejor democracia" width="148" height="32" border="0" /><br />
			</a><br />  
			<a href="http://www.24demarzo.gov.ar/" target="_blank"><img src="images/logo_del_horror.jpg" alt="del horror a la esperanza" width="148" height="74" border="0" /><br />  
			<br />  
			</a><a href="http://www.argentina.gov.ar" target="_blank"><img src="images/logo_argentinagovar.jpg" alt="argentina. gov. ar" width="148" height="41" border="0" /><br />  
			<br />  
			</a><a href="http://www.presidencia.gov.ar/" target="_blank"><img src="images/logo_presidencia.jpg" alt="presidencia de la naci&oacute;n" width="148" height="34" border="0" /></a><br />
			    <br />
			<a href="http://www.boletinoficial.gov.ar" target="_blank"><img src="images/logo_boletinoficial.jpg" alt="bolet&iacute;n oficial " width="148" height="33" border="0" /></a></p>
	  <a href="http://www.jus.gov.ar/datos-personales.aspx" target="_blank"><img src="images/datos_personales.jpg" alt="Direcci�n Nacional de Protecci�n de Datos Personales" width="148" height="36" border="0" /><br />
</a></p>
			<a href="http://www.jus.gov.ar/registro-nacional-de-personas-menores-extraviadas.aspx" target="_blank"><img src="images/banner_juschicos.gif" alt="Registro Nacional de Informaci�n de Personas Menores Extraviadas" width="148" border="0" /></a></p>		</td>
    </tr>
    <tr>
      <td height="29">&nbsp;</td>
    </tr>
</table>

<map name="Map" id="Map">
  <area shape="rect" coords="54,42,95,82" href="http://www.linkedin.com/companies/sigen?trk=co_search_results&amp;goback=.cps_1274293394749_1" target="_blank" alt="SIGEN en LINKEDIN" /><area shape="rect" coords="16,89,126,131" href="http://www.youtube.com/user/SigenPrensa" target="_blank" />
<area shape="rect" coords="102,42,140,83" href="http://www.facebook.com/home.php?#!/pages/Buenos-Aires-Argentina/Sindicatura-General-de-la-Nacion/125247770822228?v=wall&amp;ref=ts" target="_blank" alt="SIGEN en Facebook" />
<area shape="rect" coords="8,42,49,81" href="http://www.flickr.com/photos/sigengov/" target="_blank" />
</map>	    </td>
	    <td>&nbsp;</td>
    </tr>
	<tr>
	  <td height="126">&nbsp;</td>
	  <td>&nbsp;</td>
  </tr>
	
	

	

	
	
	
	<tr>
	  <td height="150">&nbsp;</td>
	 <td align=center valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
	</tr>
</table>
	<iframe width="174" height="189" name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="DateCal/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; left:-500px; top:0px;"> 
	</iframe>
</body>
</html>


http://www.sigen.gov.ar/normativa.asp 190.139.97.169 20100729122954 text/html 16289
HTTP/1.1 200 OK
Connection:close
Date:Thu, 29 Jul 2010 19:30:14 GMT
Server:Microsoft-IIS/6.0
X-Powered-By:ASP.NET
Content-Length:15914
Content-Type:text/html
Cache-control:private
x_commoncrawl_OriginalURL:http://www.sigen.gov.ar/normativa.asp
x_commoncrawl_URLFP:-6467314133696295717
x_commoncrawl_HostFP:-1563625540
x_commoncrawl_FetchTimestamp:1280431794999

<html>
<head>
<title>Sindicatura General De La Naci�n</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="Css/Estilos.css" rel="stylesheet" type="text/css">


<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo25 {color: #0099FF}
.Estilo26 {color: #CCCCCC}
.Estilo30 {color: #DDDDDD}
-->
</style>
</head>

<body>
<table width="955" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 <!--DWLayoutTable-->
	<tr>
		<td height="100" colspan=3 valign="top" bgcolor="#FFFFFF">
			<link href="css/estilos.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo20 {
	color: #000066;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: bold;
}
#Layer1 {
	position:absolute;
	left:582px;
	top:57px;
	width:274px;
	height:33px;
	z-index:1;
}
-->
</style>
<table width="955" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
	<!--DWLayoutTable-->
	<tr>
		<td height="100" colspan="4" valign="top"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="955" height="100" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="header_sigen03.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" /><embed src="header_sigen03.swf" quality="high" bgcolor="#ffffff" width="955" height="100" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />

</object>
		</td>
  </tr>
	
	
	
	
	<tr>
	 <td width="14" height="18" valign="top" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
 <td width="136" valign="middle" bgcolor="#FFFFFF" class="Estilo20"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;S I G E N</td>
  <td width="598" align="center" valign="top" bgcolor="#FFFFFF" class="font5"><a href="institucional.asp" class="font5">Institucional</a> &nbsp; &nbsp;&nbsp;- &nbsp;&nbsp;&nbsp;<a href="informes.asp" class="font5">Informes</a>&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp; <a href="normativa.asp" class="font5">Normativa</a>&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp; <a href="plananual2010.asp" class="font5">Plan Anual </a>&nbsp; &nbsp;<a href="resoluciones.asp" class="font5"></a>- &nbsp;&nbsp;&nbsp;<a href="resoluciones.asp" class="font5">Resoluciones</a>&nbsp;&nbsp;&nbsp;&nbsp;</td>
  <td width="207" valign="top" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
	</tr>
</table>


</td>
 </tr>
	<tr>
	  <td width="160" rowspan="2"  valign="top" bgcolor="#FFFFFF">
   <link href="css/estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo21 {
	color: #0099FF;
	font-size: 10px;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style><body onLoad="MM_preloadImages('images/menu_redfederal_ovr.jpg','images/menu_mercosur_ovr.jpg','images/menu_multiarte_ovr.jpg','images/menu_gobierno_ovr.jpg','images/menu_enlaces_ovr.jpg')">
<table width="160" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">


		<tr align="center" valign="middle">
		 <td height="345" valign="top">
		 <br />
			 <table cellpadding="0px" cellspacing="0px" height="150px">
			 <!--DWLayoutTable-->
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="red.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/menu_redfederal_ovr.jpg',1)"><img src="images/menu_redfederal.jpg" alt="red federal de control p&uacute;blico" name="Image1" width="144" height="65" border="0"></a></div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="mercosur.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/menu_mercosur_ovr.jpg',1)"><img src="images/menu_mercosur.jpg" alt="temas de control mercosur" name="Image2" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="multiarte.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/menu_multiarte_ovr.jpg',1)"><img src="images/menu_multiarte.jpg" alt="espacio multiarte" name="Image3" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="gobierno.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','images/menu_gobierno_ovr.jpg',1)"><img src="images/menu_gobierno.jpg" alt="enlaces gobierno de la republica argentina" name="Image4" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="enlaces.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image5','','images/menu_enlaces_ovr.jpg',1)"><img src="images/menu_enlaces.jpg" alt="enlaces organizaciones de control en el mundo" name="Image5" width="144" height="65" border="0"></a></div></td>
			   </tr>
				<tr>
				 <td width="4" height="13" ></td>
				 <td width="137" valign="top" class="fuentepequena" ><a href="terminosycondiciones.asp" class="small Estilo13">T&eacute;rminos y Condiciones </a></td>
				 <td width="4" ></td>
			   </tr>
				<tr>
				 <td height="5" ></td>
				 <td ></td>
				 <td ></td>
			   </tr>
           </table></td>
   <td>&nbsp;</td>
	</tr>
		<tr align="center" valign="middle">
		 <td height="31">&nbsp;</td>
		 <td>&nbsp;</td>
 </tr>
</table>
</td>
	
		<td width="620" height="599" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
		  <!--DWLayoutTable-->
		  <tr>
		   <td width="20" height="2"></td>
		   <td width="570" valign="top" bgcolor="#CCCCCC"><img src= "normativa/line_normativa.gif"    width="570" height="2"></td>
		  <td width="30"></td>
		  </tr>
		  <tr>
		   <td height="20"></td>
		   <td valign="top" class="small"><div align="right" class="Estilo25"><span class="Estilo26">&nbsp;&nbsp;&nbsp;<img src="normativa/triangulito_normativa.gif" width="5" height="9" align="absmiddle"><span class="Estilo30">&nbsp;<span class="small_normativa">Marco Normativo </span></span></span></div></td>
	    <td></td>
		  </tr>
		  
		  <tr>
		   <td height="60"></td>
		   <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0"  background="normativa/head_normativa.gif">
		    <!--DWLayoutTable-->
		    <tr>
		     <td width="290" height="37">&nbsp;</td>
		     <td width="280" valign="bottom"><div align="right" class="boldear Estilo13">Marco Normativo </div></td>
		     </tr>
		    <tr>
		     <td height="23">&nbsp;</td>
		     <td>&nbsp;</td>
		     </tr>
	    </table></td>
		   <td></td>
	   </tr>
		  <tr>
		   <td height="14"></td>
		   <td></td>
		   <td></td>
	   </tr>
		  <tr>
		    <td height="319"></td>
		    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
		      <!--DWLayoutTable-->
		      <tr>
		        <td width="172" height="34">&nbsp;</td>
          <td width="198" valign="top"><p align="left" class="titularnormativa"> Normas de <br>
            Control Interno </p>
          <p align="left" class="titularnormativa">&nbsp;</p></td>
		        <td width="200" valign="top" class="titularnormativa"> Normas de <br>
	            Auditor&iacute;a Interna </td>
	        </tr>
		      <tr>
		        <td height="239">&nbsp;</td>
		        <td valign="top"> <p><a href="normas01.asp" class="Estilo13">Normas Generales <br>
		          de Control Interno </a></p>
	         <p> <a href="normas02.asp" class="Estilo13">Normas de Control <br>
	           Interno para Tecnolog&iacute;as <br>
	           de Informaci&oacute;n </a></p>
	         <p class="Estilo13"> <a href="normas03.asp" class="Estilo13">Normas M&iacute;nimas de <br>
	           Control Interno para el <br>
	           buen Gobierno Corporativo <br>
	           en Empresas y Sociedades <br>
	           del Estado </a></p>
	         <p class="Estilo13"> <a href="normas04.asp" class="Estilo13">Informe de Control <br>
	           Interno y Gesti&oacute;n </a><br>
  <br>
	           </p>	       </td>
		        <td valign="top"> <a href="normas05.asp" class="Estilo13">Normas de Auditor&iacute;a <br>
		          Interna </a><br>
  <br></td>
	        </tr>
		      <tr>
		        <td height="10"></td>
		        <td></td>
		        <td></td>
	        </tr>
		      
		      
		      
	        </table></td>
		   <td></td>
	      </tr>
		  <tr>
		    <td height="170"></td>
		    <td>&nbsp;</td>
		    <td></td>
	      </tr>
		  
		 
		  
		 
		  
		 
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
        </table></td>
		<td width="175" rowspan="3" valign="top">
			<!--INCLUDE DE LA AGENDA-->
			<link href="css/estilos.css" rel="stylesheet" type="text/css">
<table width="148px" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
	<tr>
<td width="152" height="476" valign="top"><p>		<img src="main_principal/link_facebook.jpg" alt="LINKEDIN / FACEBOOK" width="148" height="50" border="0" usemap="#Map" /><br />
		<br />
		<a href="http://congreso2010.sigen.gov.ar" target="_blank"><img src="main_principal/link_congreso_02.jpg" alt="1er Congreso Internacional de Control Gubernamental" width="148" height="60" border="0" /></a><br />
		<br />
				<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="100" title="contacto con el ciudadano">
					<param name="movie" value="main_principal/flash/ciudadanos2.swf"/>
					<param name="quality" value="high" />
					<embed src="main_principal/flash/ciudadanos2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="100"></embed>
				</object>
			
			  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="100" title="envio de curriculum">
                <param name="movie" value="main_principal/flash/curriculum2.swf" />
                <param name="quality" value="high" />
                <embed src="main_principal/flash/curriculum2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="100"></embed>
              </object>
			  <a href="https://www.argentinacompra.gov.ar" target="_blank"><img src="images/logo_compra_argentina.jpg" alt="argentina compra" width="148" height="53" border="0" />		</a>		<br />
			    <a href="http://www.bicentenario.argentina.ar/" target="_blank"><img src="main_principal/banner_bicentenario.jpg" alt="agenda del bicentenario" width="148" height="73" border="0" /><br />
			    <br />
	    </a>
				<a href="http://www.marcaargentina.gov.ar/" target="_blank"><img src="images/logo_marca_argentina.jpg" alt="argentina tiene marca" width="148" height="55" border="0" /></a>
				<br />
				<a href="http://www.mejordemocracia.gov.ar/" target="_blank"><img src="images/logo_mejordemocracia.jpg" alt="mejor democracia" width="148" height="32" border="0" /><br />
			</a><br />  
			<a href="http://www.24demarzo.gov.ar/" target="_blank"><img src="images/logo_del_horror.jpg" alt="del horror a la esperanza" width="148" height="74" border="0" /><br />  
			<br />  
			</a><a href="http://www.argentina.gov.ar" target="_blank"><img src="images/logo_argentinagovar.jpg" alt="argentina. gov. ar" width="148" height="41" border="0" /><br />  
			<br />  
			</a><a href="http://www.presidencia.gov.ar/" target="_blank"><img src="images/logo_presidencia.jpg" alt="presidencia de la naci&oacute;n" width="148" height="34" border="0" /></a><br />
			    <br />
			<a href="http://www.boletinoficial.gov.ar" target="_blank"><img src="images/logo_boletinoficial.jpg" alt="bolet&iacute;n oficial " width="148" height="33" border="0" /></a></p>
	  <a href="http://www.jus.gov.ar/datospersonales/index.html" target="_blank"><img src="images/datos_personales.jpg" alt="Direcci�n Nacional de Protecci�n de Datos Personales" width="148" height="36" border="0" /><br />
</a></p>
			<a href="http://www.jus.gov.ar/registro-nacional-de-personas-menores-extraviadas.aspx" target="_blank"><img src="images/banner_juschicos.gif" alt="Registro Nacional de Informaci�n de Personas Menores Extraviadas" width="148" border="0" /></a></p>		</td>
    </tr>
    <tr>
      <td height="29">&nbsp;</td>
    </tr>
</table>

<map name="Map" id="Map"><area shape="rect" coords="56,5,97,45" href="http://www.linkedin.com/companies/sigen?trk=co_search_results&amp;goback=.cps_1274293394749_1" target="_blank" alt="SIGEN en LINKEDIN" />
<area shape="rect" coords="103,4,141,45" href="http://www.facebook.com/home.php?#!/pages/Buenos-Aires-Argentina/Sindicatura-General-de-la-Nacion/125247770822228?v=wall&amp;ref=ts" target="_blank" alt="SIGEN en Facebook" />
</map>	    </td>
   
  </table>
</td>
	</tr>
	

	<tr>
	 <td height="150" colspan=3 align=center valign="top"><link href="css/estilos.css" rel="stylesheet" type="text/css">
 
<style type="text/css">
<!--
.Estilo13 {color: #999999}
-->
</style>
<table width="955" border="0" cellpadding="0" cellspacing="0">
 <!--DWLayoutTable-->
 <tr>
  <td width="180" height="84" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  <td width="570" valign="top" class="Estilo1"><p><span class="Texto2"><strong><img src="decoratives/line_normativa.gif" width="570" height="5" /><br />
          <br />
        SINDICATURA GENERAL DE LA NACION</strong><br>
    Av. Corrientes 389<br>
    C1043AAD / Ciudad Aut&oacute;noma de Buenos Aires<br>
    Capital Federal / Rep&uacute;blica Argentina<br>
    Tel.: (54+11) 4312 8111/18<br>
    Fax: (54+11) 4317 2828</span><span class="texto2"><br>
    </span><br> 
  </p></td>
  <td width="205">&nbsp;</td>
 </tr>

</table>
</td>
	</tr>
</table>
</body>
</html>


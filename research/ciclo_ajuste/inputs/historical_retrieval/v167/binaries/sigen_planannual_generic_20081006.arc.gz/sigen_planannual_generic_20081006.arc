http://www.sigen.gov.ar/plananual.asp 190.139.97.169 20081006152047 text/html 21760
HTTP/1.1 200 OK
Connection:close
Date:Mon, 06 Oct 2008 22:20:46 GMT
Server:Microsoft-IIS/6.0
Content-Length:21216
Content-Type:text/html
Set-Cookie:ASPSESSIONIDASBADATA=DBJJOCNALOLBJMJADDJDGMEJ; path=/
Cache-control:private
x_commoncrawl_ParseSegmentId:4292
x_commoncrawl_OriginalURL:http://www.sigen.gov.ar/plananual.asp
x_commoncrawl_URLFP:5906463658078256699
x_commoncrawl_HostFP:4377930299089924691
x_commoncrawl_Signature:96a27e714af3b3c5e489f7d91a1693f9
x_commoncrawl_CrawlNo:1
x_commoncrawl_FetchTimestamp:1223331647676

<html>
<head>
<title>Sindicatura General De La Naci�n</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="Css/Estilos.css" rel="stylesheet" type="text/css">


<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo25 {color: #0099FF}
.Estilo26 {color: #CCCCCC}
.Estilo29 {color: #0CCCD6}
.Estilo30 {color: #DDDDDD}
.Estilo31 {color: #0CCCD6; font-weight: bold; }
-->
</style>
</head>

<body>
<table width="955" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 <!--DWLayoutTable-->
	<tr>
		<td height="100" colspan=3 valign="top" bgcolor="#FFFFFF">
			<link href="css/estilos.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo20 {
	color: #0099FF;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: bold;
}
#Layer1 {
	position:absolute;
	left:582px;
	top:57px;
	width:274px;
	height:33px;
	z-index:1;
}
-->
</style>
<table width="955" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
	<!--DWLayoutTable-->
	<tr>
		<td height="100" colspan="4" valign="top"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="955" height="100" title="sigen">
          <param name="movie" value="flash_intro/header_sigen_2008.swf" />
          <param name="quality" value="high" />
          <embed src="flash_intro/header_sigen_2008.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="955" height="100"></embed>
	    </object></td>
  </tr>
	
	
	
	
	<tr>
	 <td width="14" height="18" valign="top" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
 <td width="136" valign="middle" bgcolor="#FFFFFF" class="Estilo20"><!--DWLayoutEmptyCell-->&nbsp;</td>
  <td width="598" align="right" valign="top" bgcolor="#FFFFFF" class="font5"><a href="institucional.asp" class="font5">Institucional</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="informes.asp" class="font5">Informes</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="resoluciones.asp" class="font5">Resoluciones</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="normativa.asp" class="font5">Normativa</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="multimedia.asp" class="font5">Sigen Multimedia</a>&nbsp;<a href="contratados.asp" class="font5"></a></td>
  <td width="207" valign="top" bgcolor="#FFFFFF"><!--DWLayoutEmptyCell-->&nbsp;</td>
	</tr>
</table>


</td>
 </tr>
	<tr>
		<td width="160" rowspan="2"  valign="top" bgcolor="#FFFFFF">
   <link href="css/estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.Estilo21 {
	color: #0099FF;
	font-size: 10px;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style><body onLoad="MM_preloadImages('images/menu_redfederal_ovr.jpg','images/menu_mercosur_ovr.jpg','images/menu_multiarte_ovr.jpg','images/menu_gobierno_ovr.jpg','images/menu_enlaces_ovr.jpg')">
<table width="160" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
		<td width="153" height="13" valign="bottom" class="small Estilo13" >&nbsp;&nbsp;buscar</td>
 <td width="7"></td>
  </tr>
   
    
    
    <tr>
      <td height="33" align="left" valign="top" >
	  <form name="buscador" method="POST" onSubmit="return validar(this.ciRestriction.value)" action="../busquedas/query.idq">
<input type="HIDDEN" name="HTMLQueryForm" value="../menu.inc.asp" spellcheck="true">
&nbsp;&nbsp;
<input name="ciRestriction" type="text"  size="14" maxlength="60">
<a href onClick="this.href='JavaScript:formSubmit()'"> 
<input type="image" src="images/icon_lupa.gif" alt="Buscar" width="15" height="15" border="0">
</a>
</form> </td>
 <td  ></td>
    </tr>


		<tr align="center" valign="middle">
		 <td height="345" valign="top">
			 <table cellpadding="0px" cellspacing="0px" height="150px">
			 <!--DWLayoutTable-->
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="red.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/menu_redfederal_ovr.jpg',1)"><img src="images/menu_redfederal.jpg" alt="red federal de control p&uacute;blico" name="Image1" width="144" height="65" border="0"></a></div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="mercosur.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/menu_mercosur_ovr.jpg',1)"><img src="images/menu_mercosur.jpg" alt="temas de control mercosur" name="Image2" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="multiarte.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/menu_multiarte_ovr.jpg',1)"><img src="images/menu_multiarte.jpg" alt="espacio multiarte" name="Image3" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="gobierno.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','images/menu_gobierno_ovr.jpg',1)"><img src="images/menu_gobierno.jpg" alt="enlaces gobierno de la republica argentina" name="Image4" width="144" height="65" border="0"></a> </div></td>
			   </tr>
				<tr>
				 <td height="65" colspan="3" valign="top" ><div align="right"><a href="enlaces.asp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image5','','images/menu_enlaces_ovr.jpg',1)"><img src="images/menu_enlaces.jpg" alt="enlaces organizaciones de control en el mundo" name="Image5" width="144" height="65" border="0"></a></div></td>
			   </tr>
				<tr>
				 <td width="4" height="13" ></td>
				 <td width="137" valign="top" class="fuentepequena" ><a href="terminosycondiciones.asp" class="small Estilo13">T&eacute;rminos y Condiciones </a></td>
				 <td width="4" ></td>
			   </tr>
				<tr>
				 <td height="5" ></td>
				 <td ></td>
				 <td ></td>
			   </tr>
           </table></td>
   <td>&nbsp;</td>
	</tr>
		<tr align="center" valign="middle">
		 <td height="31">&nbsp;</td>
		 <td>&nbsp;</td>
 </tr>
</table>
</td>
	
		<td width="620" height="560" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
		  <!--DWLayoutTable-->
		  <tr>
		   <td width="20" height="2"></td>
		   <td width="570" valign="top" bgcolor="#CCCCCC"><img src= "decoratives/line_plan_anual.gif"    width="570" height="2"></td>
		  <td width="30"></td>
		  </tr>
		  <tr>
		   <td height="20"></td>
		   <td valign="top" class="small"><div align="right" class="Estilo25"><span class="Estilo26">&nbsp;&nbsp;&nbsp;<img src="decoratives/triangulito_planual.gif" width="5" height="9" align="absmiddle"><span class="Estilo30">&nbsp;<span class="small_plan_anual">Plan Anual </span></span></span></div></td>
	    <td></td>
		  </tr>
		  
		  <tr>
		   <td height="60"></td>
		   <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0"  background="decoratives/head_plan_anual.gif">
		    <!--DWLayoutTable-->
		    <tr>
		     <td width="290" height="37">&nbsp;</td>
		     <td width="280" valign="bottom"><div align="right"><span class="boldear Estilo26"><br>
		        <span class="Estilo13">Plan Sigen 2007 </span></span></div></td>
		     </tr>
		    <tr>
		     <td height="23">&nbsp;</td>
		     <td>&nbsp;</td>
		     </tr>
	    </table></td>
		   <td></td>
	   </tr>
		  <tr>
		   <td height="14"></td>
		   <td></td>
		   <td></td>
	   </tr>
		  <tr>
		   <td height="445"></td>
		   <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
		     <!--DWLayoutTable-->
		     <tr>
		      <td width="86" height="17"></td>
		      <td colspan="5" rowspan="2"  valign="top"><img src="documentacion/planual.gif" alt="plan anual sigen 2007" width="238" height="314" border="0"></td>
		      <td width="12"></td>
	       <td width="50"></td>
	       <td width="82"></td>
	       <td width="65"></td>
        <td width="37"></td>
		     </tr>
		     <tr>
		      <td height="300"></td>
		      <td colspan="3" valign="top"><p><span class="SubTitulosNov "><a href="documentacion/resoluciones_sigen/r115-06.pdf" target="_blank" class="tit_02_plananual"><span class="tit_02_plananual">Resoluci&oacute;n <br>
          N&ordm; 115/06 SGN</span><br>
          <img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"> </a></span><br>
              <span class="medium"><br>
             </span><span class="Estilo1 Estilo13">Aprueba el Plan Anual de la Sindicatura General de la Naci&oacute;n para el ejercicio 2007 y el Planeamiento de la Red Federal de Control P&uacute;blico</span> </p>		       <p><span class="SubTitulosNov "><a href="documentos_pdf/Plan_SIGEN_2007.pdf" target="_blank" class="tit_02_plananual"><span class="tit_02_plananual">Plan Sigen 2007 </span><br>
   <img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"> </a></span></p>		       <p>&nbsp;</p></td>
		      <td></td>
		      <td></td>
	      </tr>
		     <tr>
		      <td height="19"></td>
		      <td width="50">&nbsp;</td>
		      <td width="50"></td>
		      <td width="50"></td>
		      <td width="50"></td>
		      <td width="38">&nbsp;</td>
		      <td>&nbsp;</td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
	      </tr>
		     <tr>
		      <td height="15"></td>
		      <td colspan="8" valign="top" class="tit_02_plananual">Anexos</td>
		      <td></td>
		      <td></td>
	      </tr>
		     <tr>
		      <td height="2"></td>
		      <td colspan="8" valign="top"><img src="decoratives/line_plan_anual.gif" width="382" height="2"></td>
		      <td></td>
		      <td></td>
	      </tr>
		     <tr>
		      <td height="18"></td>
		      <td>&nbsp;</td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
	      </tr>
		     <tr>
		      <td height="82"></td>
		      <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro5.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>		       <p class="tit_02_plananual">Cuadro<br>
		        5
        </p></td>
	      <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro6.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>	       <p class="tit_02_plananual">Cuadro<br>
        6</p></td>
	       <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro7.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>	        <p class="tit_02_plananual">Cuadro<br>
  7</p></td>
	       <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro8.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>	        <p class="tit_02_plananual">Cuadro<br>
  8</p></td>
	       <td colspan="2"  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro9.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>	        <p class="tit_02_plananual">Cuadro<br>
   9</p></td>
	       <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro10.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>	        <p class="tit_02_plananual">Cuadro<br>
  10</p></td>
	       <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro11.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>	        <p class="tit_02_plananual">Cuadro<br>
   11</p></td>
	       <td>&nbsp;</td>
        <td>&nbsp;</td>
		     </tr>
		     <tr>
		      <td height="19"></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
        <td>&nbsp;</td>
		     </tr>
		     <tr>
		      <td height="91"></td>
		      <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro12.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>		       <p class="tit_02_plananual">Cuadro<br>
    12</p></td>
		      <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro13.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>		       <p class="tit_02_plananual">Cuadro<br>
    13</p></td>
		      <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro14.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>		       <p class="tit_02_plananual">Cuadro<br>
    14</p></td>
		      <td  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/plannual2007/cuadro15.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>		       <p class="tit_02_plananual">Cuadro<br>
    15</p></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td colspan="2"  valign="top"><p class="SubTitulosNov "><a href="documentos_pdf/red_federal/planred2007.pdf" target="_blank"><img src="images/icono_pdf_blanco.gif" alt="resolucion sigen 115-06" width="35" height="36" border="0"></a></p>		       <p><a href="documentos_pdf/red_federal/planred2007.pdf" target="_blank" class="tit_02_plananual">Anexo <br>
        Plan de la Red federal de Control P&uacute;blico </a></p></td>
		      <td>&nbsp;</td>
		     </tr>
		     <tr>
		      <td height="33"></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	      </tr>



               </table></td>
		   <td></td>
	   </tr>
		 

		  <tr>
		   <td height="5"></td>
		   
		   <td></td>
	   </tr>
	
          </table></td>
		<td width="175" valign="top">
			<!--INCLUDE DE LA AGENDA-->
			<link href="css/estilos.css" rel="stylesheet" type="text/css">
<table width="148px" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
		<td width="152" height="476" valign="top"><p><a href="http://www.mejordemocracia.gov.ar/" target="_blank"></a><a href="documentos_pdf/AnexoV-res52.pdf" target="_blank">
        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="100" title="contacto con el ciudadano">
          <param name="movie" value="main_principal/flash/ciudadanos2.swf" />
          <param name="quality" value="high" />
          <embed src="main_principal/flash/ciudadanos2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="100"></embed>
        </object>
        <img src="images/boton_concurso_abierto.jpg" alt="llamado a concurso abierto para cobertura de vacantes" width="148" height="70" border="0" /><br />
        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="148" height="100" title="envio de curriculum">
          <param name="movie" value="main_principal/flash/curriculum2.swf" />
          <param name="quality" value="high" />
          <embed src="main_principal/flash/curriculum2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="148" height="100"></embed>
        </object>
        <br />
      </a><a href="https://www.argentinacompra.gov.ar" target="_blank"><img src="images/logo_compra_argentina.jpg" alt="argentina compra" width="148" height="53" border="0" /><br />
      <br />
        </a><a href="http://www.marcaargentina.gov.ar/" target="_blank"><img src="images/logo_marca_argentina.jpg" alt="argentina tiene marca" width="148" height="55" border="0" /><br />
        </a><a href="http://www.mejordemocracia.gov.ar/" target="_blank"><br />
        </a><a href="http://www.mejordemocracia.gov.ar/" target="_blank"><img src="images/logo_mejordemocracia.jpg" alt="mejor democracia" width="148" height="32" border="0" /><br />
        </a><br />  
        <a href="http://www.24demarzo.gov.ar/" target="_blank"><img src="images/logo_del_horror.jpg" alt="del horror a la esperanza" width="148" height="74" border="0" /><br />  
        <br />  
        </a><a href="http://www.argentina.gov.ar" target="_blank"><img src="images/logo_argentinagovar.jpg" alt="argentina. gov. ar" width="148" height="41" border="0" /><br />  
        <br />  
        </a><a href="http://www.presidencia.gov.ar/" target="_blank"><img src="images/logo_presidencia.jpg" alt="presidencia de la naci&oacute;n" width="148" height="34" border="0" /></a><br />
            <br />
        <a href="http://www.boletinoficial.gov.ar/Bora.Portal/" target="_blank"><img src="images/logo_boletinoficial.jpg" alt="bolet&iacute;n oficial " width="148" height="33" border="0" /></a></p></td>
    </tr>
    <tr>
      <td height="29">&nbsp;</td>
    </tr>
</table>
  
	    </td>
		 
  </table></td>
	</tr>
	<tr>
	 <td height="18">&nbsp;</td>
 </tr>

	<tr>
	 <td height="150" colspan=3 align=center valign="top"><link href="css/estilos.css" rel="stylesheet" type="text/css">
 
<style type="text/css">
<!--
.Estilo13 {color: #999999}
-->
</style>
<table width="955" border="0" cellpadding="0" cellspacing="0">
 <!--DWLayoutTable-->
 <tr>
  <td width="180" height="84" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  <td width="570" valign="top" class="Estilo1"><p><img src="decoratives/line_plan_anual.gif" width="570" height="5" /><br />
    <span class="Texto2"><strong><br />
      SINDICATURA GENERAL DE LA NACION</strong><br>
      Av. Corrientes 389<br>
      C1043AAD / Ciudad Aut&oacute;noma de Buenos Aires<br>
      Capital Federal / Rep&uacute;blica Argentina<br>
      Tel.: (54+11) 4312 8111/18<br>
      Fax: (54+11) 4317 2828</span><span class="texto2"><br>
        </span><br> 
      </p>
    </td>
  <td width="205">&nbsp;</td>
 </tr>

</table>
</td>
	</tr>
</table>
</body>
</html>

